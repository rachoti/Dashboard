import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashdoardComponent } from './dashdoard/dashdoard.component';
import { ImageComponent } from './image/image.component';
import { LoginComponent } from './login/login.component';
import { MessagecountComponent } from './messagecount/messagecount.component';
import {HttpClientModule} from '@angular/common/http';
import { AuthGuard } from './auth.guard';
import { UseractivityComponent } from './useractivity/useractivity.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
const appRoutes: Routes = [
  { path: '',   redirectTo: '/login', pathMatch: 'full' },
  { path: 'dashboard', component: DashdoardComponent,canActivate: [AuthGuard]  },
  { path: 'image', component: ImageComponent,canActivate: [AuthGuard]  },
  { path: 'login', component: LoginComponent},
  { path: 'messagecount', component: MessagecountComponent,canActivate: [AuthGuard] },
  { path: 'useractivity', component: UseractivityComponent,canActivate: [AuthGuard] }
  ];
@NgModule({
  
  declarations: [
    AppComponent,
    DashdoardComponent,
    ImageComponent,
    LoginComponent,
    MessagecountComponent,
    UseractivityComponent
  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
    RouterModule,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
