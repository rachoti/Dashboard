import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { DashboardserviceService } from './dashboardservice.service';
@Component({
  selector: 'app-dashdoard',
  templateUrl: './dashdoard.component.html',
  styleUrls: ['./dashdoard.component.css']
})
export class DashdoardComponent implements OnInit {
  isShowDiv1 = true;  
  isShowDiv2 = true; 
  isShowDiv3 = true; 
  newUserCount;
  returnUserCount;
  lifetimeUserCount;
  totalActivityUserCount;

  userMessageCount;
  wizardMessageCount;
  totalMessageCount;
  totalTodayMessageCount;
  actdata1="+ Activity";
  actdata2="+ Compare";
  actdata3="+ Conversation";
  toggleDisplayDiv1() {
    this.isShowDiv1 = !this.isShowDiv1;
    if(this.actdata1==="+ Activity"){
      this.actdata1="- Activity";
    }else{
      this.actdata1="+ Activity";
    }
    
  }
  toggleDisplayDiv2() {
    this.isShowDiv2 = !this.isShowDiv2;
    if(this.actdata2==="+ Compare"){
      this.actdata2="- Compare";
    }else{
      this.actdata2="+ Compare";
    }
    
  }

  toggleDisplayDiv3() {
    this.isShowDiv3= !this.isShowDiv3;
    if(this.actdata3==="+ Conversation"){
      this.actdata3="- Conversation";
    }else{
      this.actdata3="+ Conversation";
    }
    
  }
  constructor(private router: Router,private _httpService:DashboardserviceService,public authService: AuthService) { }
  
  ngOnInit() {
    this._httpService.getUserActivity().subscribe((res:any[])=>{
      console.log(localStorage.getItem('token'));
      console.log(res);
      for (let index = 0; index < res.length; index++) {
        this.newUserCount=res[0].Count;
        this.returnUserCount=res[1].Count;
        this.lifetimeUserCount=res[2].Count;
        this.totalActivityUserCount=this.newUserCount+this.returnUserCount+this.lifetimeUserCount;
      }
      
    });
    
    this._httpService.getMessageActivity().subscribe((res:any[])=>{
      console.log(res);
      
     // for (let index = 0; index < res.length; index++) {
        this.userMessageCount=res[0].User_count;
        this.wizardMessageCount=res[0].Wizard_count;
        this.totalMessageCount=res[0].total;
        this.totalTodayMessageCount=res[0].User_last;
      //}
       
    });
    
  }
  logout(): void {
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}