import { TestBed } from '@angular/core/testing';

import { UseravtivityService } from './useravtivity.service';

describe('UseravtivityService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UseravtivityService = TestBed.get(UseravtivityService);
    expect(service).toBeTruthy();
  });
});
